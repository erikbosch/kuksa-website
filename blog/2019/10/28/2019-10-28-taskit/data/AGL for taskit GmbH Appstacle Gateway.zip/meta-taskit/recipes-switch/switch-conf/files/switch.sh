#!/bin/bash

echo 34 > /sys/class/gpio/export
echo out > /sys/class/gpio/PB2/direction
sleep 0.1
echo 1 > /sys/class/gpio/PB2/value
cd /usr/bin/switch
./sja1105-tool config load appstacle.xml
./sja1105-tool config upload
echo 0 > /sys/class/gpio/PB2/value
sleep 0.1
echo 1 > /sys/class/gpio/PB2/value
./sja1105-tool config upload
ifconfig eth0 up
ifconfig eth0 down
ifconfig eth0 up
udhcpc eth0

