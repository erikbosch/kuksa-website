#!/bin/bash

if [ -e /dev/ttyACM1 ]
then
    echo -n -e "AT+CFUN=4\r" > /dev/ttyACM1
    sleep 0.5
    echo -n -e "AT^SLED=0\r" > /dev/ttyACM1
fi
