#!/bin/bash

usage ()
{
  echo 'Usage : Script [ Host | Device ]'
  exit
}
if [ $# -eq 0 ]; then
  usage
fi
if mountpoint -q /boot; then
  umount /boot
fi
mount /dev/mmcblk0p1 /boot
cd /boot
p=`echo $1 | tr '[A-Z]' '[a-z]'`
if [[ $p = "host" ]]; then
  if [ -e dtb.bin.usb-host ]; then
    mv dtb.bin dtb.bin.usb-device
    mv dtb.bin.usb-host dtb.bin
    echo "Success."
  else
    echo "No change necessary."
  fi
elif [[ $p = "device" ]]; then
  if [ -e dtb.bin.usb-device ]; then
    mv dtb.bin dtb.bin.usb-host
    mv dtb.bin.usb-device dtb.bin
    echo "Success."
  else
    echo "No change necessary."
  fi
else
  echo "Invalid parameter!"
fi
umount -l /boot

